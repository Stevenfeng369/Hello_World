package com.example.app1;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.Random;
import java.util.Scanner;
import java.util.LinkedList;
public class MainActivity extends AppCompatActivity {
    TextView scrn;
    final Button []b = new Button[10];

    Button start,quit,reset;
    RadioButton rb1,rb2,rb3,rb4,rb5,rb6;
    RadioGroup rbg;
    int selectItem=1;
    int location=-1;

    TicTacToeGame game = new TicTacToeGame();
    ComputerPerfectPlayer  perfect = new ComputerPerfectPlayer();
    HumanPlayer human = new HumanPlayer();
    boolean starting = false;
    Player[] players = new Player[2];
    ComputerMenacePlayer computerMenacePlayer = new ComputerMenacePlayer();
    ComputerMenacePlayer menace2 = new ComputerMenacePlayer();
    ComputerRandomPlayer random = new ComputerRandomPlayer();
    public static final int TRAINING_ROUNDS = 500;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        scrn = (TextView)findViewById(R.id.scrn);
        b[1] = (Button)findViewById(R.id.b1);
        b[2] = (Button)findViewById(R.id.b2);
        b[3] = (Button)findViewById(R.id.b3);
        b[4] = (Button)findViewById(R.id.b4);
        b[5] = (Button)findViewById(R.id.b5);
        b[6] = (Button)findViewById(R.id.b6);
        b[7] = (Button)findViewById(R.id.b7);
        b[8] = (Button)findViewById(R.id.b8);
        b[9] = (Button)findViewById(R.id.b9);

        quit = (Button)findViewById(R.id.quit);
        reset = (Button)findViewById(R.id.reset);
        start = (Button)findViewById(R.id.start);
        rb1 = (RadioButton)findViewById(R.id.rb1);
        rb2 = (RadioButton)findViewById(R.id.rb2);
        rb3 = (RadioButton)findViewById(R.id.rb3);
        rb4 = (RadioButton)findViewById(R.id.rb4);
        rb5 = (RadioButton)findViewById(R.id.rb5);
        rb6 = (RadioButton)findViewById(R.id.rb6);
        rbg = (RadioGroup)findViewById(R.id.rbg);

        rbg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(){
            public void onCheckedChanged(RadioGroup group,int checkedId){
                if(checkedId==rb1.getId()) {selectItem=1;}
                if(checkedId==rb2.getId()) {selectItem=2;}
                if(checkedId==rb3.getId()) {selectItem=3;}
                if(checkedId==rb4.getId()) {selectItem=4;}
                if(checkedId==rb5.getId()) {selectItem=5;}
                if(checkedId==rb6.getId()) {selectItem=6;}
                //selectItem=(checkedId+3)%10;
                String st = ""+selectItem;
                scrn.setText(st);
            }
        });
        quit.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { System.exit(0);}});
        reset.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { clear();}});
        start.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                scrn.setText("");
                startPayer();
               // perfectPlayer();
            }});
        b[1].setOnClickListener(new View.OnClickListener(){
                 public void onClick(View v) {
                     if(starting) {
                     location=0;players[1].play(game);
                     if(game.getGameState() != GameState.PLAYING)
                         Finished();
                     else  perfectPlayer();}
                 }});
        b[2].setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if(starting) {
                    location=1; players[1].play(game);
                    if(game.getGameState() != GameState.PLAYING)
                        Finished();
                    else  perfectPlayer();}
            }});
        b[3].setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if(starting) {
                location=2;players[1].play(game);
                    if(game.getGameState() != GameState.PLAYING)
                        Finished();
                    else  perfectPlayer();}
            }});
        b[4].setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if(starting) {
                location=3;players[1].play(game);
                    if(game.getGameState() != GameState.PLAYING)
                        Finished();
                    else  perfectPlayer();}
            }});
        b[5].setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if(starting) {
                location=4;players[1].play(game);
                    if(game.getGameState() != GameState.PLAYING)
                        Finished();
                    else  perfectPlayer();}
            }});
        b[6].setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if(starting) {
                location=5;players[1].play(game);
                    if(game.getGameState() != GameState.PLAYING)
                        Finished();
                    else  perfectPlayer();}
            }});
        b[7].setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if(starting) {
                location=6;players[1].play(game);
                    if(game.getGameState() != GameState.PLAYING)
                        Finished();
                    else  perfectPlayer();}
            }});
        b[8].setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if(starting) {
                location=7;players[1].play(game);
                    if(game.getGameState() != GameState.PLAYING)
                        Finished();
                    else  perfectPlayer();}
            }});
        b[9].setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if(starting) {
                location=8;players[1].play(game);
                    if(game.getGameState() != GameState.PLAYING)
                        Finished();
                    else  perfectPlayer();}
            }});
    }

    void clear(){
        scrn.setText("");
        for(int i=1;i<=9;i++)
        b[i].setText("");
        game = new TicTacToeGame();
    }

    void refresh(){
        if (starting==false) return;
        for(int j = 0; j < game.lines*game.columns ; j++){
            switch(game.valueAt(j)) {
                case X:
                    b[j+1].setText("X");
                    break;
                case O:
                    b[j+1].setText("O");
                    break;
                default:
                    b[j+1].setText("");
            }
        }
    }


class HumanPlayer extends Player {
    public  void play(TicTacToeGame game) {
        if(game.getLevel() == game.lines*game.columns){
            throw new IllegalArgumentException("Game is finished already!");
        }
            refresh();
            if(game.valueAt(location) != CellValue.EMPTY) {
                scrn.setText("This cell has already been played");
            } else {
                game.play(location);
                location=-1;
                refresh();
            }
        }
    }




    public class ComputerPerfectPlayer extends Player {

        private LinkedList<LinkedList<PerfectTicTacToeGame>> allGames;

        public ComputerPerfectPlayer(){
            super();

            allGames = new LinkedList<LinkedList<PerfectTicTacToeGame>>();

            // start with the empty game
            allGames.add(new LinkedList<PerfectTicTacToeGame>());
            allGames.get(0).add(new PerfectTicTacToeGame());

            //build the new games by adding the next moves to the
            // previously built games
            for(int i=1; i<= 9; i++) {
                LinkedList<PerfectTicTacToeGame> newList;
                newList = new LinkedList<PerfectTicTacToeGame>();
                allGames.add(newList);
                for(PerfectTicTacToeGame game: allGames.get(i-1)){
                    if(game.getGameState() == GameState.PLAYING) {
                        for(int j = 0;
                            j < 9;
                            j++) {
                            if(game.valueAt(j) == CellValue.EMPTY) {
                                PerfectTicTacToeGame newGame = new PerfectTicTacToeGame(game,j);
                                //checking that this game was not already found
                                boolean isNew = true;
                                for(PerfectTicTacToeGame existingGame: allGames.get(i)){
                                    if(newGame.equalsWithSymmetry(existingGame)){
                                        isNew = false;
                                        break;
                                    }
                                }
                                if(isNew) {
                                    newList.add(newGame);
                                }
                            }
                        }
                    }

                }
            }

            // now adding the game outcomes
            for(int i=8; i>= 0; i--) {
                for(PerfectTicTacToeGame game: allGames.get(i)){
                    if(game.getGameOutcome() == PerfectTicTacToeGame.NOT_SET) {
                        for(int j=0;
                            j < 9;
                            j++) {
                            if(game.valueAt(j) == CellValue.EMPTY) {
                                PerfectTicTacToeGame newGame = new PerfectTicTacToeGame(game,j);
                                //looking for the game reached by j is played
                                for(PerfectTicTacToeGame existingGame: allGames.get(i+1)){
                                    if(newGame.equalsWithSymmetry(existingGame)){
                                        // reverse the outcome
                                        if(existingGame.getGameOutcome() == PerfectTicTacToeGame.WIN) {
                                            game.setMoveOutcome(j,PerfectTicTacToeGame.LOSE);
                                        } else if(existingGame.getGameOutcome() == PerfectTicTacToeGame.LOSE) {
                                            game.setMoveOutcome(j,PerfectTicTacToeGame.WIN);
                                        } else if(existingGame.getGameOutcome() == PerfectTicTacToeGame.DRAW) {
                                            game.setMoveOutcome(j,PerfectTicTacToeGame.DRAW);
                                        } else {
                                            System.out.println(existingGame);

                                            throw new IllegalStateException("This should not be happening");
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }

                }
            }

        }

        public  void play(TicTacToeGame game) {

            if(game.getLevel() == game.lines*game.columns){
                throw new IllegalArgumentException("Game is finished already!");
            }

            // find the menaceGame corresponding to the state of game
            for(PerfectTicTacToeGame perfectGame: allGames.get(game.getLevel())){
                if(perfectGame.equalsWithSymmetry(game)){
                    game.play(perfectGame.choosePerfectMove());
                    return;
                }
            }

            //Should never reach here
            throw new IllegalStateException("Game not found: " + game);

        }

    }


    void startPayer(){
        game = new TicTacToeGame();
        if(selectItem==1){
            scrn.setText("Human to play menace");
            starting=true;
            players[0]=computerMenacePlayer;
            players[1]=human;
            players[0].startNewGame(CellValue.X);
            players[1].startNewGame(CellValue.O);
            perfectPlayer();}
        if(selectItem==2){
            scrn.setText("Train Menace against perfect player");
            starting=false;
            players[0]=computerMenacePlayer;
            players[1]=perfect;
            train(players);
            }
        if(selectItem==3){
            scrn.setText("Train Menace against random player");
            starting=false;
            players[0]=computerMenacePlayer;
            players[1]=random;
            train(players);
        }
        if(selectItem==4){
            scrn.setText("Train Menace against another menace");
            starting=false;
            players[0]=computerMenacePlayer;
            players[1]=menace2;
            train(players);
        }
        if(selectItem==5){
            scrn.setText("Delete (both) Menace training sets");
            starting=false;
            players[0]= new ComputerMenacePlayer();
            players[1]= new ComputerMenacePlayer();
            train(players);
        }
        if(selectItem==6){
            scrn.setText("Human to play PerfectComputer");
            starting=true;
            players[0]=perfect;
            players[1]=human;
            players[0].startNewGame(CellValue.X);
            players[1].startNewGame(CellValue.O);
            perfectPlayer();}
    }
    void perfectPlayer(){
        players[0].play(game);
        refresh();
        if(game.getGameState() != GameState.PLAYING) {
            Finished();}
    }
    void Finished(){
            starting=false;
            players[0].gameFinished(game.getGameState());
            players[1].gameFinished(game.getGameState());
            refresh();
            scrn.setText("Result: " + game.getGameState());
            String st=""+players[0].toString();
            scrn.setText(st);
            return;
    }
    private void train(Player[] players) {

        //int first  = Utils.generator.nextInt(2);
        int numberOfPlays = TRAINING_ROUNDS;
        while(numberOfPlays > 0) {
            TicTacToeGame game = new TicTacToeGame();
            int turn = 0; //(first++)%2;
            players[turn%2].startNewGame(CellValue.X);
            players[(turn+1)%2].startNewGame(CellValue.O);
            while(game.getGameState() == GameState.PLAYING) {
                players[turn%2].play(game);
                turn++;
            }
            players[0].gameFinished(game.getGameState());
            players[1].gameFinished(game.getGameState());
            numberOfPlays--;
        }
        scrn.setText("player 1: " + players[0]+"\n") ;
        scrn.setText("player 2: " + players[1]); ;
    }

}

enum CellValue {
    EMPTY,
    X,
    O
}
enum GameState{
    PLAYING,
    DRAW,
    XWIN,
    OWIN
}
enum Transformation {
    ID,
    ROT,
    VSYM,
    HSYM
}



class Utils {
    public static final Random generator = new Random();
    public static final Scanner console = new Scanner(System.in);
    public static final String NEW_LINE = System.getProperty("line.separator");



    /**
     * rotates the game
     *
     * 1 | 2 | 3
     * ----------
     * 4 | 5 | 6
     * ----------
     * 7 | 8 | 9
     *
     * into the game
     *
     * 7 | 4 | 1
     * ----------
     * 8 | 5 | 2
     * ----------
     * 9 | 6 | 3
     */


    public static void rotate(int lines, int columns, int[] transformedBoard){
        if(lines != columns) {
            throw new IllegalArgumentException("Cannot rotate a non square board");
        }
        if(transformedBoard == null) {
            throw new NullPointerException("transformedBoard cannot be null");
        }
        if((lines < 1) || (columns < 1) || (transformedBoard.length != lines*columns)){
            throw new IllegalArgumentException("rotate called with incorrect arguments");
        }

        int[] tmp;
        tmp = new int[transformedBoard.length];

        for(int i =0 ; i < transformedBoard.length; i++) {
            tmp[i] = transformedBoard[i];
        }

        for(int i =0 ; i < columns; i++) {
            for(int j = 0; j < lines ; j++) {
                transformedBoard[j*lines+i]=tmp[(columns-i-1)*lines+j];
            }
        }

    }

    /**
     * horizontalFlip flips the game
     *
     * 1 | 2 | 3
     * ----------
     * 4 | 5 | 6
     * ----------
     * 7 | 8 | 9
     *
     * into the game
     *
     * 7 | 8 | 9
     * ----------
     * 4 | 5 | 6
     * ----------
     * 1 | 2 | 3
     */

    public static  void horizontalFlip(int lines, int columns, int[] transformedBoard){
        if(transformedBoard == null) {
            throw new NullPointerException("transformedBoard cannot be null");
        }
        if((lines < 1) || (columns < 1) || (transformedBoard.length != lines*columns)){
            throw new IllegalArgumentException("horizontalFlip called with incorrect arguments");
        }
        int tmp;
        for(int i = 0; i < (lines/2); i++) {
            for(int j=0 ; j< columns; j++) {
                tmp = transformedBoard[(lines-i-1)*columns + j];
                transformedBoard[(lines-i-1)*columns + j] = transformedBoard[i*columns + j];
                transformedBoard[i*columns + j] = tmp;
            }
        }
    }

    /**
     * verticalFlip flips the game
     *
     * 1 | 2 | 3
     * ----------
     * 4 | 5 | 6
     * ----------
     * 7 | 8 | 9
     *
     * into the game
     *
     * 3 | 2 | 1
     * ----------
     * 6 | 5 | 4
     * ----------
     * 9 | 8 | 7
     */

    public static  void verticalFlip(int lines, int columns, int[] transformedBoard){
        if(transformedBoard == null) {
            throw new NullPointerException("transformedBoard cannot be null");
        }
        if((lines < 1) || (columns < 1) || (transformedBoard.length != lines*columns)){
            throw new IllegalArgumentException("verticalFlip called with incorrect arguments");
        }
        int tmp;
        for(int i = 0; i < (lines); i++) {
            for(int j=0 ; j< (columns/2); j++) {
                tmp = transformedBoard[(i+1)*columns -j-1];
                transformedBoard[(i+1)*columns -j-1] = transformedBoard[i*columns + j];
                transformedBoard[i*columns + j] = tmp;
            }
        }
    }

    private static void test(int lines, int columns){
        int[] test;
        test = new int[lines*columns];
        for(int i = 0 ; i < test.length; i++){
            test[i] = i;
        }
        System.out.println("testing " + lines + " lines and " + columns + " columns.");
        System.out.println(java.util.Arrays.toString(test));
        horizontalFlip(lines,columns,test);
        System.out.println("HF => " + java.util.Arrays.toString(test));
        horizontalFlip(lines,columns,test);
        System.out.println("HF => " + java.util.Arrays.toString(test));
        verticalFlip(lines,columns,test);
        System.out.println("VF => " + java.util.Arrays.toString(test));
        verticalFlip(lines,columns,test);
        System.out.println("VF => " + java.util.Arrays.toString(test));
        if(lines == columns){
            for(int i = 0; i < 4; i++) {
                rotate(lines,columns,test);
                System.out.println("ROT => " + java.util.Arrays.toString(test));
            }
        }
    }
}


abstract class Player {
    int numberOfWin;
    int numberOfLoss;
    int numberOfDraw;
    int numberOfGame;
    char[] slidingWindow;
    int currentSlidingIndex;
    CellValue myMove;

    static final int WINDOWSIZE = 50;
    static final char IWIN = 'w';
    static final char ILOSE = 'l';
    static final char IDRAW = 'd';
    Player(){
        numberOfWin = 0;
        numberOfLoss= 0;
        numberOfDraw= 0;
        numberOfGame= 0;
        slidingWindow = new char[WINDOWSIZE];
        currentSlidingIndex= 0;
    }

    abstract void play(TicTacToeGame game);

    void startNewGame(CellValue myMove){
        this.myMove = myMove;
    }

    void gameFinished(GameState result){
        if(result == GameState.DRAW) {
            numberOfDraw++;
            slidingWindow[currentSlidingIndex] = IDRAW;
        } else if (result == GameState.XWIN) {
            if(myMove == CellValue.X) {
                numberOfWin++;
                slidingWindow[currentSlidingIndex] = IWIN;
            } else {
                numberOfLoss++;
                slidingWindow[currentSlidingIndex] = ILOSE;
            }
        } else if (result == GameState.OWIN) {
            if(myMove == CellValue.O) {
                numberOfWin++;
                slidingWindow[currentSlidingIndex] = IWIN;
            } else {
                numberOfLoss++;
                slidingWindow[currentSlidingIndex] = ILOSE;
            }
        } else {
            throw new IllegalArgumentException("Result can't be " + result);
        }
        numberOfGame++;
        currentSlidingIndex = (currentSlidingIndex+1)%WINDOWSIZE;
    }


    public String toString(){
        String result;

        result = "This player has won " + numberOfWin + " games, lost "
                + numberOfLoss + " games and " + numberOfDraw + " were draws.";

        if(numberOfGame >= WINDOWSIZE) {
            int w = 0;
            int l = 0;
            int d = 0;
            for(char c: slidingWindow) {
                switch(c){
                    case IWIN:
                        w++;
                        break;
                    case ILOSE:
                        l++;
                        break;
                    case IDRAW:
                        d++;
                        break;
                    default:
                        System.out.println("Unknown value: " + c);
                }
            }
            result += " Over the last " + WINDOWSIZE + " games, this player has won " + w + " games, lost "
                    + l + " games and " + d + " were draws.";
        }
        return result;
    }
}

class TicTacToeGame {

    private CellValue[] board;

    private int level;

    private GameState gameState;


    public final int lines;

    public final int columns;

    public final int sizeWin;

    private  static final Transformation[] allTransformationsSquare =
            {Transformation.ID,Transformation.ROT,Transformation.ROT,
                    Transformation.ROT,Transformation.HSYM,Transformation.ROT,
                    Transformation.ROT,Transformation.ROT};


    private  static final Transformation[] allTransformationsNonSquare =
            {Transformation.ID,Transformation.HSYM,
                    Transformation.VSYM,Transformation.HSYM};


    private  Transformation[] allTransformations;

    private int currentTransformation;


    protected int[] transformedBoard;

    public TicTacToeGame(){
        this(3,3,3);
    }


    public TicTacToeGame(int lines, int columns){
        this(lines, columns, 3);
    }

    public TicTacToeGame(int lines, int columns, int sizeWin){
        this.lines = lines;
        this.columns = columns;
        this.sizeWin = sizeWin;
        board = new CellValue[lines*columns];
        for(int i = 0; i < lines*columns ; i ++) {
            board[i] = CellValue.EMPTY;
        }
        level = 0;
        gameState = GameState.PLAYING;
        if(lines == columns) {
            allTransformations = allTransformationsSquare;
        } else {
            allTransformations = allTransformationsNonSquare;
        }
        //transformedBoard = new int[lines*columns];
        reset();

    }



    public TicTacToeGame(TicTacToeGame base, int next){

        lines = base.lines;
        columns = base.columns;
        sizeWin = base.sizeWin;

        if(next < 0 || next >= lines*columns){
            throw new IllegalArgumentException("Illegal position: " + next);
        }

        if(base == null){
            throw new IllegalArgumentException("Illegal base game: null value");
        }

        if(base.board[next] != CellValue.EMPTY) {
            throw new IllegalArgumentException("CellValue not empty: " + next + " in game " + base);
        }

        board = new CellValue[lines*columns];
        for(int i = 0; i < lines*columns ; i ++) {
            board[i] = base.board[i];
        }

        // allTransformations doesn't change so we can share the reference here
        allTransformations = base.allTransformations;


        level = base.level+1;

        board[next] = base.nextCellValue();

        if(base.gameState != GameState.PLAYING) {
            System.out.println("hum, extending a finished game... keeping original winner");
            gameState = base.gameState;
        } else {
            setGameState(next);
        }

        reset();
    }



    public boolean equals(Object o) {
        if(o == null) {
            return false;
        }
        if(getClass() != o.getClass()){
            return false;
        }

        TicTacToeGame other = (TicTacToeGame)o;

        if((level != other.level) 	||
                (lines != other.lines) 	||
                (columns != other.columns)||
                (sizeWin != other.sizeWin)){
            return false;
        }
        for(int i = 0; i < board.length ; i++ ) {
            if(board[i]!= other.board[i]) {
                return false;
            }
        }
        return true;
    }


    public int getLevel(){
        return level;
    }

    public GameState getGameState(){
        return gameState;
    }


    public CellValue nextCellValue(){
        return (level%2 == 0) ? CellValue.X : CellValue.O;
    }


    public CellValue valueAt(int i) {

        if(i < 0 || i >= lines*columns){
            throw new IllegalArgumentException("Illegal position: " + i);
        }

        return board[i];
    }


    public void play(int i) {

        if(i < 0 || i >= lines*columns){
            throw new IllegalArgumentException("Illegal position: " + i);
        }
        if(board[i] != CellValue.EMPTY) {
            throw new IllegalArgumentException("CellValue not empty: " + i + " in game " + toString());
        }

        board[i] = nextCellValue();
        level++;
        if(gameState != GameState.PLAYING) {
            System.out.println("hum, extending a finished game... keeping original winner");
        } else {
            setGameState(i);
        }

    }


    private void setGameState(int index){

        int left = Math.min(sizeWin-1,index%columns);
        int right= Math.min(sizeWin-1,columns - (index%columns +1));
        if( (countConsecutive(index-1, left,-1,board[index]) +
                countConsecutive(index+1, right,1,board[index]))
                >= sizeWin-1 ) {
            setGameState(board[index]);
            return;
        }



        int up 	= Math.min(sizeWin-1,index/columns);
        int down= Math.min(sizeWin-1, lines - (index/columns +1));
        if( (countConsecutive(index-columns, up,-columns,board[index]) +
                countConsecutive(index+columns, down,columns,board[index]))
                >= sizeWin-1 ) {
            setGameState(board[index]);
            return;
        }

        int upLeft = Math.min(up, left);
        int downRight= Math.min(down, right);
        if( (countConsecutive(index-(columns+1), upLeft,-(columns+1),board[index]) +
                countConsecutive(index+(columns+1), downRight,columns+1,board[index]))
                >= sizeWin-1 ) {
            setGameState(board[index]);
            return;
        }

        int upRight= Math.min(up, right);
        int downLeft = Math.min(down, left);
        if( (countConsecutive(index-(columns-1), upRight,-(columns-1),board[index]) +
                countConsecutive(index+(columns-1), downLeft,columns-1,board[index]))
                >= sizeWin-1 ) {
            setGameState(board[index]);
            return;
        }


        if (level == lines*columns) {
            gameState = GameState.DRAW;
        } else {
            gameState = GameState.PLAYING;
        }

    }


    private int countConsecutive(int startingPosition, int numberOfSteps,
                                 int stepGap, CellValue value){

        int result= 0;
        for(int i = 0; i < numberOfSteps;i++){
            if(board[startingPosition + i*stepGap] != value)
                break;
            result++;
        }
        return result;

    }


    private void setGameState(CellValue value){
        switch(value){
            case X:
                gameState = GameState.XWIN;
                break;
            case O:
                gameState = GameState.OWIN;
                break;
            default:
                throw new IllegalArgumentException("cannot set Game State to value " + value);
        }
    }


    /**
     * Returns a String representation of the game matching
     * the example provided in the assignment's description
     *
     * @return
     *  String representation of the game
     */

    public String toString(){
        String res = "";
        for(int i = 0; i < lines ; i++){
            if(i>0) {
                for(int j = 0; j < 4*columns - 1; j++){
                    res+="-";
                }
                res+= Utils.NEW_LINE;
            }
            for(int j = 0; j < columns ; j++){
                switch(board[i*columns + j]){
                    case X:
                        res+= " X ";
                        break;
                    case O:
                        res+= " O ";
                        break;
                    default:
                        res+=  "   ";
                }
                if(j<columns - 1){
                    res += "|";
                } else{
                    res += Utils.NEW_LINE;
                }
            }
        }
        return res ;

    }


    /**
     * restarts the list of symmetries
     */

    public void reset(){
        currentTransformation = -1;
        transformedBoard = new int[lines*columns];
    }

    /**
     * checks if there are more symmetries to go through
     *
     * @return
     *   true iff there are additional symmetries
     */
    public boolean hasNext(){
        return currentTransformation < (allTransformations.length-1);
    }

    /**
     * computes the next symmetries and stores it in
     * the array "transform".
     * Requires that this.hasNext() == true
     */
    public void next(){


        if(!hasNext()){
            throw new IllegalStateException("No next transformation");
        }
        currentTransformation++;
        transform(allTransformations[currentTransformation]);
    }

    /**
     * Applies the transformation specified as parameter
     * to transformedBoard
     */
    private void transform(Transformation type){

        switch(type) {
            case ID :
                for(int i =0 ; i < board.length; i++) {
                    transformedBoard[i]=i;
                }
                break;
            case ROT :
                Utils.rotate(lines, columns,transformedBoard);
                break;
            case VSYM :
                Utils.verticalFlip(lines, columns,transformedBoard);
                break;
            case HSYM :
                Utils.horizontalFlip(lines, columns,transformedBoard);
                break;
            default:
                System.out.println("Unknow type: " + type);
        }
    }



    /**
     * Compares this instance of the game with the
     * instance passed as parameter. Return true
     * if and only if the two instance represent
     * the same state of the game, up to symmetry.
     * @param other
     *  the TicTacToeGame instance to be compared with this one
     */
    public boolean equalsWithSymmetry(TicTacToeGame other){

        if(other == null) {
            return false;
        }
        if((level != other.level) 	||
                (lines != other.lines) 	||
                (columns != other.columns)||
                (sizeWin != other.sizeWin)){
            return false;
        }

        reset();
        while(hasNext()){
            next();
            boolean different = false;
            for(int i = 0; i < transformedBoard.length ; i++ ) {
                if(board[transformedBoard[i]]!= other.board[i]) {
                    different = true;
                    break;
                }
            }
            if(!different)
                return true;
        }
        return false;
    }

    /**
     * Returns a String representation of the game as currently trasnsformed
     *
     * @return
     *  String representation of the game
     */

    public String toStringTransformed(){
        if(transformedBoard == null) {
            throw new NullPointerException("transformedBoard not initialized");
        }

        String res = "";
        for(int i = 0; i < lines ; i++){
            if(i>0) {
                for(int j = 0; j < 4*columns - 1; j++){
                    res+="-";
                }
                res+= Utils.NEW_LINE;
            }
            for(int j = 0; j < columns ; j++){
                switch(board[transformedBoard[i*columns + j]]){
                    case X:
                        res+= " X ";
                        break;
                    case O:
                        res+= " O ";
                        break;
                    default:
                        res+=  "   ";
                }
                if(j<columns - 1){
                    res += "|";
                } else{
                    res += Utils.NEW_LINE;
                }
            }
        }
        return res ;

    }
}

class PerfectTicTacToeGame extends TicTacToeGame {

    public static final int NOT_SET = 0;
    public static final int WIN  = 1;
    public static final int LOSE = 2;
    public static final int DRAW = 3;
    private int[] outcomes;
    private int gameOutcome;
    private int lines=3,clomns=3;
    private int size = lines*clomns;
    public PerfectTicTacToeGame(){
        super(3,3,3);
        outcomes = new int[size];
        gameOutcome = NOT_SET;
    }

    public PerfectTicTacToeGame(PerfectTicTacToeGame base, int next){
        super(base,next);
        outcomes = new int[size];
        gameOutcome = NOT_SET;
    }

    public void setMoveOutcome(int move, int outcome){
        if(move < 0 || move >= outcomes.length ||
                outcome < WIN || outcome > DRAW || outcomes[move] != 0 ) {
            throw new IllegalArgumentException();
        }
        outcomes[move] = outcome;
        if(outcome == WIN) {
            gameOutcome = WIN;
        } else if (outcome == DRAW && gameOutcome != WIN ) {
            gameOutcome = DRAW;
        } else if (outcome == LOSE && gameOutcome == NOT_SET) {
            gameOutcome = LOSE;
        }
    }

    public int getGameOutcome() {
        if(getGameState() == GameState.XWIN || getGameState() == GameState.OWIN ){
            // from the viewpoint of a player who would have to play next, a
            // game that has just been won is losing
            return LOSE;
        } else if(getGameState() == GameState.DRAW ){
            return DRAW;
        } else {
            return gameOutcome;
        }
    }

    public int choosePerfectMove(){
        if(getGameState() != GameState.PLAYING){
            throw new IllegalStateException("Game already finished");
        }
        int choices = 0;
        for(int i : outcomes) {
            if(i == gameOutcome)
                choices++;
        }


        int randomChoice = Utils.generator.nextInt(choices);
        int currentSelection = 0;
        boolean search = true;
        while(search) {
            if(outcomes[transformedBoard[currentSelection]] == gameOutcome){
                if(randomChoice == 0) {
                    search = false;
                } else {
                    randomChoice--;
                    currentSelection++;
                }
            } else {
                currentSelection++;
            }
        }
        return currentSelection;
    }
}

class ComputerMenacePlayer extends Player {

    private LinkedList<LinkedList<MenaceTicTacToeGame>> allGames;

    //	private static final int[] INITIAL_WEIGHT = {4,4,3,3,2,2,1,1,1};
    private static final int[] INITIAL_WEIGHT = {8,8,4,4,2,2,1,1,1};
    private static final int PENALTY_WIN = 3;
    private static final int PENALTY_DRAW = 1;
    private static final int PENALTY_LOSE = -1;


    private LinkedList<MenaceTicTacToeGame> seriesOfGames;

    public ComputerMenacePlayer(){
        super();

        allGames = new LinkedList<LinkedList<MenaceTicTacToeGame>>();

        // start with the empty game
        allGames.add(new LinkedList<MenaceTicTacToeGame>());
        allGames.get(0).add(new MenaceTicTacToeGame());

        //build the new games by adding the next moves to the
        // previously built games
        for(int i=1; i<= 9; i++) {
            LinkedList<MenaceTicTacToeGame> newList;
            newList = new LinkedList<MenaceTicTacToeGame>();
            allGames.add(newList);
            for(MenaceTicTacToeGame game: allGames.get(i-1)){
                if(game.getGameState() == GameState.PLAYING) {
                    for(int j = 0;
                        j < 9;
                        j++) {
                        if(game.valueAt(j) == CellValue.EMPTY) {

                            // the following is OK but adds beads for symmetrically
                            // equivalent moves
                            //game.setOdds(j,INITIAL_WEIGHT[i-1]);

                            MenaceTicTacToeGame newGame = new MenaceTicTacToeGame(game,j);
                            //checking that this game was not already found
                            boolean isNew = true;
                            for(MenaceTicTacToeGame existingGame: allGames.get(i)){
                                if(newGame.equalsWithSymmetry(existingGame)){
                                    isNew = false;
                                    break;
                                }
                            }
                            if(isNew) {
                                newList.add(newGame);
                            }
                        }
                    }
                }

            }
        }

        // now adding the odds for menace, without adding beads for
        // symmetrically equivalent moves
        for(int i=0; i< 9; i++) {
            for(MenaceTicTacToeGame game: allGames.get(i)){
                if(game.getGameState() == GameState.PLAYING) {
                    LinkedList<MenaceTicTacToeGame> listOfNextGames;
                    listOfNextGames = new LinkedList<MenaceTicTacToeGame>();
                    for(int j=0;
                        j < 9;
                        j++) {
                        if(game.valueAt(j) == CellValue.EMPTY) {
                            MenaceTicTacToeGame newGame = new MenaceTicTacToeGame(game,j);
                            //checking that a symmetrical game was not already found
                            boolean isNew = true;
                            for(MenaceTicTacToeGame existingGame: listOfNextGames){
                                if(newGame.equalsWithSymmetry(existingGame)){
                                    isNew = false;
                                    break;
                                }
                            }
                            if(isNew) {
                                listOfNextGames.add(newGame);
                                game.setOdds(j,INITIAL_WEIGHT[i]);
                            }
                        }
                    }
                }

            }
        }


    }

    public void startNewGame(CellValue myMove){
        super.startNewGame(myMove);
        seriesOfGames = new LinkedList<MenaceTicTacToeGame>();
    }


    public void gameFinished(GameState result){
        super.gameFinished(result);
        int penalty;
        if(result == GameState.DRAW) {
            penalty = PENALTY_DRAW;
        } else if (result == GameState.XWIN) {
            if(myMove == CellValue.X) {
                penalty = PENALTY_WIN;
            } else {
                penalty = PENALTY_LOSE;
            }
        } else {
            if(myMove == CellValue.O) {
                penalty = PENALTY_WIN;
            } else {
                penalty = PENALTY_LOSE;
            }
        }
        for( MenaceTicTacToeGame game: seriesOfGames ){
            game.verdict(penalty);
        }
    }


    public  void play(TicTacToeGame game) {

        if(game.getLevel() == game.lines*game.columns){
            throw new IllegalArgumentException("Game is finished already!");
        }

        // find the menaceGame corresponding to the state of game
        for(MenaceTicTacToeGame menaceGame: allGames.get(game.getLevel())){
            if(menaceGame.equalsWithSymmetry(game)){
                game.play(menaceGame.chooseMenaceMove());
                seriesOfGames.add(menaceGame);
                return;
            }
        }

        //Should never reach here
        throw new IllegalStateException("Game not found: " + game);

    }
}

class MenaceTicTacToeGame extends TicTacToeGame {

    private int[] currentOdds;
    private int currentTotal;
    private int currentSelection;
    private int size=9;              //take 4*4
    public MenaceTicTacToeGame(){
        super(3,3,3);
        currentOdds = new int[size];
        currentTotal = 0;
        currentSelection = -1;
    }

    public MenaceTicTacToeGame(MenaceTicTacToeGame base, int next){
        super(base,next);
        currentOdds = new int[size];
        currentTotal = 0;
        currentSelection = -1;
    }

    public void setOdds (int location, int number) {
        if(location < 0 || location >= currentOdds.length ||
                number < 0 || currentOdds[location] != 0 ) {
            throw new IllegalArgumentException();
        }
        currentOdds[location] = number;
        currentTotal += number;
    }

    public int chooseMenaceMove(){
        if(currentSelection != -1) {
            throw new IllegalStateException("This menace game has already selected a move and is waiting on the verdict");
        }
        int randomDraw = Utils.generator.nextInt(currentTotal)+1;
        currentSelection = 0;
        int sum = currentOdds[transformedBoard[currentSelection]];
        while(sum<randomDraw) {
            currentSelection++;
            sum += currentOdds[transformedBoard[currentSelection]];
        }
        return currentSelection;
    }

    public void verdict(int penalty) {
        if(currentSelection == -1) {
            throw new IllegalStateException("This menace is not waiting on a verdict");
        }

        if(currentTotal+penalty <= 0) {
            //System.out.println("Removing last possible move. Will keep it to avoid deadlock");
        } else {
            currentTotal += penalty;
            currentOdds[transformedBoard[currentSelection]]+= penalty;
        }
        currentSelection = -1;
    }

    // debug method
    public String getCurrentOdds(){
        return java.util.Arrays.toString(currentOdds);
    }
}

class ComputerRandomPlayer extends Player {

    public  void play(TicTacToeGame game) {

        if(game.getLevel() == game.lines*game.columns){
            throw new IllegalArgumentException("Game is finished already!");
        }

        int choice;
        do {
            choice = Utils.generator.nextInt(game.lines*game.columns);
        } while (game.valueAt(choice) != CellValue.EMPTY);

        game.play(choice);
    }

}